# Kelompok_5_WebsiteProdi_IT_Del

### Nama Kelompok :
-	11S18008 : Andrini Mayetha Panjaitan
-	11S18023 : Jhon Videlis Simamora
-	11S18068 : Santi Sandryna
-	11S18069 : Dean Efraim

Contoh website yang menjadi acuan kami
https://ugm.ac.id/id/pendidikan/fakultas-teknik

### Spesifikasi Hardware Laptop yang digunakan :
-	8GB RAM
-	Intel(R) Core(TM) i5-7200U CPU @ 2.50GHz 2.71 GHz
-	BIOS : InsydeH20 Version 05.11.464WCN37WW
-	390GB SSD Storage
-	Intel HD Graphics 2GB

### Spesifikasi/Teknologi Software yang digunakan :
-	OS : Windows 10
-	Text Editor : Visual Studio Code 2019
-	Text Editor : Sublime Text
-	Client : Browser
-	Framework : Bootstrap 5
-	Dokumentasi : Paket Office

Repository yang digunakan :
https://github.com/deanefraim/Kelompok_5_Website_Prodi_IT_Del

### Fitur-Fitur website yang akan dibuat :
-	Beranda/Home  : yang menjelaskan tentang suatu halaman utama atau halaman pembuka yang ada dalam suatu website. Dan fitur home/beranda ini sangatlah penting, karena fitur ini merupakan halaman index atau yang pertama kali ditampilkan ketika domain dari website itu dipanggil.
-	Profil        : yang menjelaskan secara detail tentang dosen-dosen program studi Sarjana Informatika.
-	Informasi Akademik : yang menjelaskan tentang informasi-informasi akademik dari program studi Sarjana Informatika.
-	Kegiatan : yang menjelaskan tentang kegiatan-kegiatan yang pernah diadakan oleh mahasiswa/i program studi sarjana informatika.
-	Galeri : yang menunjukkan tentang gambar-gambar atau foto-foto yang ada pada program studi Sarjana Informatika.
-	About : yang menjelaskan tentang informasi umum mengenai program studi Sarjana Informatika serta visi dan misi dari program studi Sarjana Informatika.
-	Kontak Kami : yang memungkinkan user dapat menghubungi kontak yang ada dihalaman untuk memperjelas informasi tentang program studi Sarjana Informatika.
-	Footer : yang menjelaskan tentang informasi mengenai social media dan hak cipta atau kepemilikan dari website program studi Sarjana Informatika.
